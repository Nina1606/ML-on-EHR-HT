from pathlib import Path

BASE_DIRECTORY = Path("").parent

DATA_FILE_PATH = BASE_DIRECTORY / "Fetched_Timeseries" / "Convert_Numeric" 

DATA_FILE_PATH_PROCESS = BASE_DIRECTORY / "Fetched_Timeseries"
